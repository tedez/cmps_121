package com.example.nanorouz.servicedemo2;

/**
 * Created by nanorouz on 11/25/18.
 */
public class ServiceResult {
    ServiceResult() {}

    public int intValue;
}