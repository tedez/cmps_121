package edu.cmps121.app.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import edu.cmps121.app.R;
import edu.cmps121.app.utilities.State;

public class HappeningsActivity extends AppCompatActivity {

    private State state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_happenings);

        TextView textView = findViewById(R.id.happenings_text);
        state = new State(this);

        if (state.party != null && !state.party.isEmpty())
            state.nextActivity(this, PartyMenuActivity.class);

        String welcomeText = "What\'s happening " + state.user + "?";
        textView.setText(welcomeText);
    }
}
