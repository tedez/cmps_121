# ecoBuddy
(created for CMPS 121) An android app connecting a household together with the goal of reducing wastefulness and saving money.
