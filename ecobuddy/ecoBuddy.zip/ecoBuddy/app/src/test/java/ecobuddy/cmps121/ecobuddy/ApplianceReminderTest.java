package ecobuddy.cmps121.ecobuddy;

import static org.junit.Assert.*;

public class ApplianceReminderTest {

}